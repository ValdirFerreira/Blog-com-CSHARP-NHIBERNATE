﻿using Entidades.Grupos;
using Infra.Repositorio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Modelo
{
    public class AplicacaoGrupo
    {

        readonly RepositorioGrupo repositorioGrupo;

        readonly RepositorioUsuarioGrupo repositorioUsuarioGrupo;

        public AplicacaoGrupo()
        {
            repositorioGrupo = new RepositorioGrupo();
            repositorioUsuarioGrupo = new RepositorioUsuarioGrupo();
        }

        public UsuarioGrupo ObterUsuarioGrupo(UsuarioGrupo usuariogrupo)
        {
            return repositorioUsuarioGrupo.ObterUsuarioGrupo(usuariogrupo);
        }

        public List<UsuarioGrupo> ListaUsuarioGrupos(int idGrupo)
        {
            return repositorioUsuarioGrupo.Consultar().Where(u => u.idGrupo == idGrupo).ToList();
        }

        public void IncluirUsuarioGrupo(UsuarioGrupo usuarioGrupo)
        {
            repositorioUsuarioGrupo.Insert(usuarioGrupo);
        }

        public void InserirGrupo(UsuarioGrupo usuariogrupo)
        {
            repositorioUsuarioGrupo.Insert(usuariogrupo);
        }

        public void InserirGrupo(Grupo grupo)
        {
            repositorioGrupo.Insert(grupo);
        }

        public List<Grupo> ListaGrupos()
        {
            return repositorioGrupo.Consultar().Where(G => G.Data.Date >= DateTime.Now.Date).ToList();
        }

        public Grupo ObterGrupo(int IdGrupo)
        {
            return repositorioGrupo.RetornarPorId(IdGrupo);
        }

        public Grupo RetornarPorNome(Grupo grupo)
        {
            return repositorioGrupo.RetornarPorNome(grupo);
        }

    }
}
