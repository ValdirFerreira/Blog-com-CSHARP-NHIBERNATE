﻿using Dominio.Interfaces;
using Entidades.Usuarios;
using Infra.Repositorio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Modelo
{
    public class AplicacaoUsuario
    {
        readonly RepositorioUsuario repositorioUsuario;
        public AplicacaoUsuario()
        {
            repositorioUsuario = new RepositorioUsuario();
        }

        public Usuario RetornarPorEmail(string Email)
        {
            return repositorioUsuario.RetornarPorEmail(Email);
        }

        public void Update(Usuario usuario)
        {
            repositorioUsuario.Update(usuario);
        }

        public void Delete(Usuario usuario)
        {
            repositorioUsuario.Delete(usuario);
        }

        public Usuario RetornarPorId(int IdUsuario)
        {
            return repositorioUsuario.RetornarPorId(IdUsuario);
        }

        public IList<Usuario> Consultar()
        {
            return repositorioUsuario.Consultar();
        }

        public void Insert(Usuario usuario)
        {
            repositorioUsuario.Insert(usuario);
        }
    }
}
