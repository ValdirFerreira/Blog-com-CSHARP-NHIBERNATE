﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.Usuarios;
using Infra.Repositorio;

namespace Modelo
{
    public class AplicacaoTipoUsuario
    {
        readonly RepositorioTipoUsuario repositorioTipoUsuario;
        public AplicacaoTipoUsuario()
        {
            repositorioTipoUsuario = new RepositorioTipoUsuario();
        }

        public void Insert(TipoUsuario tipo)
        {
            repositorioTipoUsuario.Insert(tipo);
        }

        public TipoUsuario RetornarPorId(TipoUsuario tipo)
        {
            return repositorioTipoUsuario.RetornarPorId(tipo.IdTipo);
        }

    }
}
