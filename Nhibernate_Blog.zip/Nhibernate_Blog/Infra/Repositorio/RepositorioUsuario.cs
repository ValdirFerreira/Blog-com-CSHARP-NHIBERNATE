﻿using Dominio.Interfaces;
using Entidades.Usuarios;
using Infra.Nhibernate;
using NHibernate.Criterion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NHibernate.Loader;
using NHibernate;

namespace Infra.Repositorio
{
    public class RepositorioUsuario : BasicService<Usuario>, IRepositorioUsuario
    {

        public Usuario RetornarPorEmail(string Email)
        {
            ICriteria query = Session.CreateCriteria(typeof(Usuario));
            query.Add(Restrictions.Eq("Login", Email));
            var retorno = query.UniqueResult<Usuario>();
            return retorno;
        }
    }
}
