﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Dominio.Interfaces;
using Entidades.Usuarios;
using Infra.Nhibernate;

namespace Infra.Repositorio
{
    public class RepositorioTipoUsuario : BasicService<TipoUsuario>, IRepositorioTipoUsuario
    {
    }
}
