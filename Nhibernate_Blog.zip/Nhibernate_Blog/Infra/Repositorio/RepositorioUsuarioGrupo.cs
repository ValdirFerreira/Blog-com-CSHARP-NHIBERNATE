﻿using Dominio.Interfaces;
using Entidades.Grupos;
using Infra.Nhibernate;
using NHibernate;
using NHibernate.Criterion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infra.Repositorio
{
    public class RepositorioUsuarioGrupo : BasicService<UsuarioGrupo>, IRepositorioUsuariosGrupo
    {
        public UsuarioGrupo ObterUsuarioGrupo(UsuarioGrupo UsuarioGrupo)
        {
            ICriteria query = Session.CreateCriteria(typeof(UsuarioGrupo));
            query.Add(Restrictions.Eq("idGrupo", UsuarioGrupo.idGrupo));
            query.Add(Restrictions.Eq("idUsuario", UsuarioGrupo.idUsuario));
            var retorno = query.UniqueResult<UsuarioGrupo>();
            return retorno;
        }

    }
}
