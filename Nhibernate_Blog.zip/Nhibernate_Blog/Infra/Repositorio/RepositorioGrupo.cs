﻿using Dominio.Interfaces;
using Entidades.Grupos;
using Infra.Nhibernate;
using NHibernate;
using NHibernate.Criterion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infra.Repositorio
{
    public class RepositorioGrupo : BasicService<Grupo>, IRepositorioGrupo
    {

        public Grupo RetornarPorNome(Grupo grupo)
        {
            ICriteria query = Session.CreateCriteria(typeof(Grupo));
            query.Add(Restrictions.Eq("Nome", grupo.Nome));
            query.Add(Restrictions.Eq("HoraInicio", grupo.HoraInicio));
            query.Add(Restrictions.Eq("Data", grupo.Data));
            var retorno = query.UniqueResult<Grupo>();
            return retorno;
        }
    }
}
