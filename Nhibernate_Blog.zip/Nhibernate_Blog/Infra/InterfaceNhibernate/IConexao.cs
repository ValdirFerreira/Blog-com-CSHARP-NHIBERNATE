﻿using FluentNHibernate.Cfg;
using NHibernate;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infra.InterfaceNhibernate
{
    public interface IConexao : IDisposable
    {
        void Close();
        ISession GetSession();
        ISession Open();
        FluentConfiguration Configuration { get; }
        ISessionFactory SessioFactory { get; }
        ISession Session { get; }
    }
}
