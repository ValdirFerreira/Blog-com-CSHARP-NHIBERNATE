﻿using Entidades.Usuarios;
using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using Infra.InterfaceNhibernate;
using NHibernate;
using NHibernate.Tool.hbm2ddl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Entidades.Usuarios.Mapeamento;
using Entidades.Grupos.Mapeamento;

namespace Infra.Nhibernate
{

    public class ConexaoHelper : IConexao
    {
        #region propriedades

        private FluentConfiguration _configuration;
        public FluentConfiguration Configuration
        {
            get { return _configuration; }
        }

        private static readonly ISessionFactory _instance = CreateSessionFactory();
        public static ISessionFactory Instance
        {
            get { return _instance; }
        }

        private ISessionFactory _sessiofactory;
        public ISessionFactory SessioFactory
        {
            get { return _sessiofactory; }
        }

        private ISession _session;
        public ISession Session
        {
            get { return _session; }
        }

        #endregion

        private static ISessionFactory CreateSessionFactory()
        {
            ISessionFactory retorno = null;
            FluentConfiguration configuration = null;
            try
            {
                string conection = System.Configuration.ConfigurationManager.ConnectionStrings["Connection"].ConnectionString;

                IPersistenceConfigurer config = MsSqlConfiguration.MsSql2008.ConnectionString(conection).ShowSql();

                configuration = Fluently.Configure()
                                                 .Database(config)
                                                 .Mappings(m => m.FluentMappings
                                                 .Add(typeof(MapeamentoTipoUsuario))
                                                 .Add(typeof(MapeamentoUsuario))
                                                 .Add(typeof(MapeamentoGrupo))
                                                 .Add(typeof(MapeamentoUsuarioGrupo))
                                                 );

                // configuration.ExposeConfiguration(x => new SchemaExport(x).Execute(true, true, true));
                configuration.ExposeConfiguration(x => new SchemaUpdate(x).Execute(true, true));
                // configuration.ExposeConfiguration(x => x.SetProperty("hbm2ddl.keywords", "auto-quotes"));
                retorno = configuration.BuildSessionFactory();

            }
            catch (Exception ex)
            {


                HelperLog.LogErro geraLog = new HelperLog.LogErro();
                geraLog.GravarLog(ex.ToString());
            }

            return retorno;
        }


        public ConexaoHelper()
        {
            this._session = CreateSessionFactory().OpenSession();
        }

        public ISession Open()
        {
            if (_session.IsOpen == false)
            {
                _session = _sessiofactory.OpenSession();
            }
            return _session;
        }

        public void Close()
        {
            if (_session != null && _session.IsOpen)
            {
                _session.Close();
                _session.Dispose();
            }
            if (_session != null)
            {
                _sessiofactory.Close();
                _sessiofactory.Dispose();
            }
            _configuration = null;
            _sessiofactory = null;
            _session = null;
        }

        public ISession GetSession()
        {
            return Open();
        }

        public void Dispose()
        {
            Close();
        }
    }
}
