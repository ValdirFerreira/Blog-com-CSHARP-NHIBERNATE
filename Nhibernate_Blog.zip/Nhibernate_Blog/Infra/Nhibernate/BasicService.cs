﻿using Dominio.InterfaceBase;
using NHibernate;
using NHibernate.Criterion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Infra.Nhibernate
{
    public class BasicService<T> : IBasicInterface<T> where T : class
    {

        #region Propriedades
        private ISession _Session;

        public ISession Session
        {
            get
            {
                if (_Session == null)
                {
                    _Session = ConexaoHelper.Instance.OpenSession();

                }
                return _Session;
            }
            set
            {
                _Session = value;


            }
        }
        #endregion

        public virtual T RetornarPorId(int Id)
        {
            if (!this.Session.IsOpen)
                _Session = ConexaoHelper.Instance.OpenSession();

            return this.Session.Get<T>(Id);

        }

        public IList<T> Consultar()
        {
            if (!this.Session.IsOpen)
                _Session = ConexaoHelper.Instance.OpenSession();
            return this.Session.CreateCriteria(typeof(T)).List<T>();
        }

        public void Insert(T entidade)
        {

            try
            {
                this.Session.BeginTransaction();
                this.Session.SaveOrUpdate(entidade);

                if (this.Session.IsOpen
                    && this.Session.Transaction.IsActive
                    && !this.Session.Transaction.WasCommitted
                    && !this.Session.Transaction.WasRolledBack)
                {
                    this.Session.Transaction.Commit();
                    this.Session.Close();
                }
            }
            catch (Exception ex)
            {
                 HelperLog.LogErro geraLog = new HelperLog.LogErro();
                geraLog.GravarLog(ex.ToString());
            }
            
        }

        public void Update(T entidade)
        {

            this.Session.BeginTransaction();
            this.Session.SaveOrUpdate(entidade);

            if (this.Session.IsOpen
                && this.Session.Transaction.IsActive
                && !this.Session.Transaction.WasCommitted
                && !this.Session.Transaction.WasRolledBack)
            {
                this.Session.Transaction.Commit();
                this.Session.Close();
            }
        }

        public void Delete(T entidade)
        {
            this.Session.BeginTransaction();
            this.Session.Delete(entidade);

            if (this.Session.IsOpen
                && this.Session.Transaction.IsActive
                && !this.Session.Transaction.WasCommitted
                && !this.Session.Transaction.WasRolledBack)
            {
                this.Session.Transaction.Commit();
                this.Session.Close();
            }
        }

    }
}
