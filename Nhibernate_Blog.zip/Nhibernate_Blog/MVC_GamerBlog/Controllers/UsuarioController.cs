﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_GamerBlog.App_LocalResources;
using MVC_GamerBlog.Helpers;
using MVC_GamerBlog.Models;
using Modelo;
using Entidades.Usuarios;
using Entidades.Grupos;

namespace MVC_GamerBlog.Controllers
{
    public class UsuarioController : MenuController
    {

        AplicacaoUsuario ModelUsuario = new AplicacaoUsuario();
        AplicacaoTipoUsuario TipoUser = new AplicacaoTipoUsuario();
        AplicacaoGrupo ModelGrupo = new AplicacaoGrupo();


        TipoUsuario Tipousuario = new TipoUsuario { IdTipo = 1, NomeTipo = ResourceGlobal.UsuarioPadrao };
        Sessoes Sessao = new Sessoes();

        [HttpPost]
        public ActionResult EnviarLogin(CadastroUsuarioViewModel cadastroUsuarioViewModel)
        {
            try
            {
                var Retorno = ModelUsuario.RetornarPorEmail(cadastroUsuarioViewModel.Login);

                if (Retorno == null)
                {
                    MessageBase(AlertStyles.Warning, ResourceGlobal.TituloMensagemErro, ResourceGlobal.EmailSenhaInvalida, true);
                    return View(ViewsProject.ViewLoginUsuario);
                }

                if (Retorno.Senha != cadastroUsuarioViewModel.Senha)
                {
                    MessageBase(AlertStyles.Warning, ResourceGlobal.TituloMensagemErro, ResourceGlobal.EmailSenhaInvalida, true);
                    return View(ViewsProject.ViewLoginUsuario);
                }

                Sessao.IncluirSessaoUsuario(Retorno);

                return View(ViewsProject.ViewPrincipal);
            }
            catch (Exception)
            {
                MessageBase(AlertStyles.Danger, ResourceGlobal.TituloMensagemErroAlgoerrado, ResourceGlobal.VerifiqueAlgumaCoisaDeuErrado, true);
                return View(ViewsProject.ViewLoginUsuario);
            }

        }

        [HttpPost]
        public ActionResult CadastroGrupo(CadastroGrupoViewModel cadastroGrupoViewModel)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    //  MessageBase(AlertStyles.Success, ResourceGlobal.TituloMensagemSucesso, ResourceGlobal.SalvoComSucesso, true);
                    MessageBase(AlertStyles.Warning, ResourceGlobal.TituloMensagemErro, ResourceGlobal.VerifiqueFormulario, true);
                    return View(ViewsProject.ViewGrupo);
                }
                else
                {

                    Grupo grupo = new Grupo
                    {
                        Nome = cadastroGrupoViewModel.Nome,
                        NomeClan = cadastroGrupoViewModel.NomeClan,
                        HoraInicio = cadastroGrupoViewModel.HoraInicio,
                        Data = cadastroGrupoViewModel.DataJogada,
                        IdUsuarioCriador = Sessao.ObterSessaoUsuario().Id
                    };

                    var Retorno = ModelGrupo.RetornarPorNome(grupo);

                    if (Retorno != null)
                    {

                        MessageBase(AlertStyles.Warning, ResourceGlobal.TituloMensagemErro, ResourceGlobal.JaExisteGrupo, true);
                        return View(ViewsProject.ViewGrupo);

                    }

                    ModelGrupo.InserirGrupo(grupo);

                    return View(ViewsProject.ViewPrincipal);
                }
            }
            catch (Exception)
            {
                MessageBase(AlertStyles.Danger, ResourceGlobal.TituloMensagemErroAlgoerrado, ResourceGlobal.VerifiqueAlgumaCoisaDeuErrado, true);
                return View(ViewsProject.ViewGrupo);
            }

        }

        /// <summary>
        ///  Este metodo somente deve ser executado uma unica vez
        ///  ele criará os tipos de usuários
        /// </summary>
        public void MetodoSomenteConfiguracao()
        {

            TipoUsuario TipousuarioAdm = new TipoUsuario { NomeTipo = ResourceGlobal.UsuarioAdministrador };
            TipoUser.Insert(Tipousuario);
            TipoUser.Insert(TipousuarioAdm);

        }

        [HttpPost]
        public ActionResult Enviar(CadastroUsuarioViewModel cadastroUsuarioViewModel)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    //  MessageBase(AlertStyles.Success, ResourceGlobal.TituloMensagemSucesso, ResourceGlobal.SalvoComSucesso, true);
                    MessageBase(AlertStyles.Warning, ResourceGlobal.TituloMensagemErro, ResourceGlobal.VerifiqueFormulario, true);
                    return View(ViewsProject.ViewCadastro);
                }
                else
                {
                    //  MetodoSomenteConfiguracao();    

                    Usuario Retorno = new Usuario();

                    Retorno = ModelUsuario.RetornarPorEmail(cadastroUsuarioViewModel.Login);

                    if (Retorno != null)
                    {

                        MessageBase(AlertStyles.Warning, ResourceGlobal.TituloMensagemErro, ResourceGlobal.EmailJaExiste, true);
                        return View(ViewsProject.ViewCadastro);

                    }


                    Usuario ObjetoUsuario = new Usuario
                    {
                        Login = cadastroUsuarioViewModel.Login,
                        Nome = cadastroUsuarioViewModel.Nome,
                        Senha = cadastroUsuarioViewModel.Senha,
                        Tipo = Tipousuario,
                        Ativo = true
                    };

                    ModelUsuario.Insert(ObjetoUsuario);

                    Sessao.IncluirSessaoUsuario(ObjetoUsuario);

                    return View(ViewsProject.ViewPrincipal);
                }
            }

            catch (Exception ex)
            {
                HelperLog.LogErro geraLog = new HelperLog.LogErro();
                geraLog.GravarLog(ex.ToString());

                MessageBase(AlertStyles.Danger, ResourceGlobal.TituloMensagemErroAlgoerrado, ResourceGlobal.VerifiqueAlgumaCoisaDeuErrado, true);
                return View(ViewsProject.ViewCadastro);
            }

        }
        public ActionResult DetalhesGrupo(string id)
        {
            if (!Sessao.VerificaSessaoUsuario())
                return View(ViewsProject.ViewPrincipal);

            try
            {

                if (string.IsNullOrEmpty(id))
                    id = Sessao.ObterSessaoIdGrupo();


                AplicacaoGrupo Aplicacao = new AplicacaoGrupo();

                var Grupo1 = Aplicacao.ObterGrupo(Convert.ToInt32(id));

                var usuarioObtido = ModelUsuario.RetornarPorId(Grupo1.IdUsuarioCriador);

                string NomeCriadorGrupo = string.Empty;
                if (usuarioObtido != null)
                {
                    NomeCriadorGrupo = usuarioObtido.Nome;
                }

                CadastroGrupoViewModel grupo = new CadastroGrupoViewModel
                {
                    PrimaryKey = Grupo1.Id.ToString(),
                    DataJogada = Grupo1.Data,
                    HoraInicio = Grupo1.HoraInicio,
                    Nome = Grupo1.Nome,
                    UsuarioCriador = NomeCriadorGrupo,
                    NomeClan = Grupo1.NomeClan

                };

                Sessao.IncluirSessaoIdGrupo(Grupo1.Id.ToString());

                return View(ViewsProject.ViewDetalhesGrupo, grupo);

            }
            catch (Exception)
            {
                MessageBase(AlertStyles.Danger, ResourceGlobal.TituloMensagemErroAlgoerrado, ResourceGlobal.VerifiqueAlgumaCoisaDeuErrado, true);
                return View(ViewsProject.ViewDetalhesGrupo);
            }


        }
        public ActionResult ListaUsuariosGrupo()
        {
            if (!Sessao.VerificaSessaoUsuario())
                return View(ViewsProject.ViewPrincipal);

            List<CadastroUsuarioViewModel> Lista = new List<CadastroUsuarioViewModel>();

            try
            {
                var idGrupo = Sessao.ObterSessaoIdGrupo();

                if (!string.IsNullOrEmpty(idGrupo))
                {
                    foreach (var item in ModelGrupo.ListaUsuarioGrupos(Convert.ToInt32(idGrupo)))
                    {
                        var usuario = ModelUsuario.RetornarPorId(item.idUsuario);
                        if (usuario != null)
                            Lista.Add(new CadastroUsuarioViewModel { Nome = usuario.Nome });
                    };
                }

                return View(ViewsProject.ViewListaUsuariosGrupo, Lista);

            }
            catch (Exception)
            {
                MessageBase(AlertStyles.Danger, ResourceGlobal.TituloMensagemErroAlgoerrado, ResourceGlobal.VerifiqueAlgumaCoisaDeuErrado, true);
                return View(ViewsProject.ViewPrincipal);
            }

        }
        public ActionResult IncluirUsuarioGrupo()
        {
            try
            {
                var idGrupo = Sessao.ObterSessaoIdGrupo();
                var UsuarioLogado = Sessao.ObterSessaoUsuario();

                if (!string.IsNullOrEmpty(idGrupo))
                {
                    var UsuarioGrupo = new UsuarioGrupo { idGrupo = Convert.ToInt32(idGrupo), idUsuario = UsuarioLogado.Id };

                    if (ModelGrupo.ObterUsuarioGrupo(UsuarioGrupo) == null)
                    {
                        ModelGrupo.IncluirUsuarioGrupo(UsuarioGrupo);
                    }
                    MessageBase(AlertStyles.Success, ResourceGlobal.SalvoComSucesso, ResourceGlobal.InclusaoUsuarioGrupo, true);
                }

                return View(ViewsProject.ViewPrincipal);

            }
            catch (Exception)
            {
                MessageBase(AlertStyles.Danger, ResourceGlobal.TituloMensagemErroAlgoerrado, ResourceGlobal.VerifiqueAlgumaCoisaDeuErrado, true);
                return View(ViewsProject.ViewPrincipal);
            }
        }

    }

}
