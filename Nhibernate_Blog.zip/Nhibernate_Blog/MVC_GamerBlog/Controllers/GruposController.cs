﻿using Entidades.Grupos;
using Entidades.Usuarios;
using Modelo;
using MVC_GamerBlog.App_LocalResources;
using MVC_GamerBlog.Helpers;
using MVC_GamerBlog.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_GamerBlog.Controllers
{
    public class GruposController : MenuController
    {

        public ActionResult ListarGrupos()
        {
            return View(ViewsProject.ViewListaGrupo); 
        }

        public ActionResult DetalhesGrupo(string id)
        {
            try
            {
                AplicacaoGrupo Aplicacao = new AplicacaoGrupo();

                var Grupo = Aplicacao.ObterGrupo(Convert.ToInt32(id));
                CadastroGrupoViewModel grupo = new CadastroGrupoViewModel
                {
                    PrimaryKey = Grupo.Id.ToString(),
                    DataJogada = Grupo.Data,
                    HoraInicio = Grupo.HoraInicio,
                    Nome = Grupo.Nome
                };
                return View(ViewsProject.ViewDetalhesGrupo, grupo);
            }
            catch (Exception)
            {
                MessageBase(AlertStyles.Danger, ResourceGlobal.TituloMensagemErroAlgoerrado, ResourceGlobal.VerifiqueAlgumaCoisaDeuErrado, true);
                return View(ViewsProject.ViewDetalhesGrupo);
            }
        }

        public ActionResult ListaUsuariosGrupo(int id)
        {
            List<Usuario> Lista = new List<Usuario>();

            for (int i = 0; i < 10; i++)
            {
                Lista.Add(new Usuario { Id = i, Nome = "Valdir " + i.ToString() });
            }

            return View(ViewsProject.ViewListaUsuariosGrupo, Lista);
        }

    }
}
