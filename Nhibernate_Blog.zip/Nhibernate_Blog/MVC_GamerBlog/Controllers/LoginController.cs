﻿using MVC_GamerBlog.App_LocalResources;
using MVC_GamerBlog.Helpers;
using MVC_GamerBlog.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_GamerBlog.Controllers
{
    public class LoginController : MenuController
    {

    }
}
