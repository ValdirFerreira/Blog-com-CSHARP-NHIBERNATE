﻿using Entidades.MenuBase;
using MVC_GamerBlog.App_LocalResources;
using MVC_GamerBlog.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_GamerBlog.Controllers
{
    public class MenuBaseController : Controller
    {

        Sessoes Sessao = new Sessoes();

        public List<MenuPadrao> ListarMenuPerfil()
        {

            int TipoUsuario = 0;

            var Usuario = Sessao.ObterSessaoUsuario();

            if (Usuario != null)
                TipoUsuario = Usuario.Tipo.IdTipo;

            // Administrador 
            if (TipoUsuario == 2)
                return ListarMenuAdministrador();

            // Usuário Basico logado 
            if (TipoUsuario == 1)
                return ListarMenuUsuarioBasico();


            return ListarMenuUsuarioSemLogar();

        }

        public List<MenuPadrao> ListarMenuAdministrador()
        {

            // Administrador 
            var ListaMenus = new List<MenuPadrao>();

            var usuario = Sessao.ObterSessaoUsuario();

            ListaMenus.Add(new MenuPadrao
       {
           IdNomeMenu = @ViewsProject.ViewPrincipal,
           TituloPaginaPrincipal = ResourceGlobal.BemVindo + " " + usuario.Nome,
           NomeView = @ViewsProject.ViewPrincipal,
           NomeControle = ControllerProject.Usuario
       });


            ListaMenus.Add(new MenuPadrao
            {
                IdNomeMenu = @ViewsProject.ViewPrincipal,
                TituloPaginaPrincipal = ResourceGlobal.TituloPaginaPrincipal,
                NomeView = @ViewsProject.ViewPrincipal,
                NomeControle = ControllerProject.Usuario
            });


            //ListaMenus.Add(new MenuPadrao
            //{
            //    IdNomeMenu = @ViewsProject.ViewCadastro,
            //    TituloPaginaPrincipal = ResourceGlobal.TituloPaginaCadastro,
            //    NomeView = @ViewsProject.ViewCadastro,
            //    NomeControle = ControllerProject.Usuario
            //});

            ListaMenus.Add(new MenuPadrao
            {
                IdNomeMenu = @ViewsProject.ViewGrupo,
                TituloPaginaPrincipal = ResourceGlobal.TituloPaginaCadastroGrupo,
                NomeView = @ViewsProject.ViewGrupo,
                NomeControle = ControllerProject.Usuario
            });

            ListaMenus.Add(new MenuPadrao
            {
                IdNomeMenu = @ViewsProject.ViewListaGrupo,
                TituloPaginaPrincipal = ResourceGlobal.TituloPaginaListaGrupo,
                NomeView = @ViewsProject.ViewListaGrupo,
                NomeControle = ControllerProject.Usuario
            });

            ListaMenus.Add(new MenuPadrao
            {
                IdNomeMenu = @ViewsProject.ViewLoginUsuario,
                TituloPaginaPrincipal = ResourceGlobal.Sair,
                NomeView = @ViewsProject.ViewLoginUsuario,
                NomeControle = ControllerProject.Usuario
            });

            //ListaMenus.Add(new MenuPadrao
            //{
            //    IdNomeMenu = @ViewsProject.ViewLoginUsuario,
            //    TituloPaginaPrincipal = ResourceGlobal.TituloPaginaLogin,
            //    NomeView = @ViewsProject.ViewLoginUsuario,
            //    NomeControle = ControllerProject.Usuario
            //});

            return ListaMenus;
        }

        public List<MenuPadrao> ListarMenuUsuarioBasico()
        {

            var ListaMenus = new List<MenuPadrao>();

            var usuario = Sessao.ObterSessaoUsuario();

            ListaMenus.Add(new MenuPadrao
            {
                IdNomeMenu = string.Empty,
                TituloPaginaPrincipal = ResourceGlobal.BemVindo.ToUpper() + " ***" + usuario.Nome.ToUpper() + "***",
                NomeView = @ViewsProject.ViewPrincipal,
                NomeControle = ControllerProject.Usuario
            });

            ListaMenus.Add(new MenuPadrao
            {
                IdNomeMenu = @ViewsProject.ViewPrincipal,
                TituloPaginaPrincipal = ResourceGlobal.TituloPaginaPrincipal,
                NomeView = @ViewsProject.ViewPrincipal,
                NomeControle = ControllerProject.Usuario
            });


            //ListaMenus.Add(new MenuPadrao
            //{
            //    IdNomeMenu = @ViewsProject.ViewCadastro,
            //    TituloPaginaPrincipal = ResourceGlobal.TituloPaginaCadastro,
            //    NomeView = @ViewsProject.ViewCadastro,
            //    NomeControle = ControllerProject.Usuario
            //});

            ListaMenus.Add(new MenuPadrao
            {
                IdNomeMenu = @ViewsProject.ViewGrupo,
                TituloPaginaPrincipal = ResourceGlobal.TituloPaginaCadastroGrupo,
                NomeView = @ViewsProject.ViewGrupo,
                NomeControle = ControllerProject.Usuario
            });

            ListaMenus.Add(new MenuPadrao
            {
                IdNomeMenu = @ViewsProject.ViewListaGrupo,
                TituloPaginaPrincipal = ResourceGlobal.TituloPaginaListaGrupo,
                NomeView = @ViewsProject.ViewListaGrupo,
                NomeControle = ControllerProject.Usuario
            });

            ListaMenus.Add(new MenuPadrao
            {
                IdNomeMenu = @ViewsProject.ViewLoginUsuario,
                TituloPaginaPrincipal = ResourceGlobal.Sair,
                NomeView = @ViewsProject.ViewLoginUsuario,
                NomeControle = ControllerProject.Usuario
            });

            //ListaMenus.Add(new MenuPadrao
            //{
            //    IdNomeMenu = @ViewsProject.ViewLoginUsuario,
            //    TituloPaginaPrincipal = ResourceGlobal.TituloPaginaLogin,
            //    NomeView = @ViewsProject.ViewLoginUsuario,
            //    NomeControle = ControllerProject.Usuario
            //});


            return ListaMenus;
        }

        public List<MenuPadrao> ListarMenuUsuarioSemLogar()
        {

            var ListaMenus = new List<MenuPadrao>();

            ListaMenus.Add(new MenuPadrao
            {
                IdNomeMenu = @ViewsProject.ViewPrincipal,
                TituloPaginaPrincipal = ResourceGlobal.TituloPaginaPrincipal,
                NomeView = @ViewsProject.ViewPrincipal,
                NomeControle = ControllerProject.Usuario
            });


            ListaMenus.Add(new MenuPadrao
            {
                IdNomeMenu = @ViewsProject.ViewCadastro,
                TituloPaginaPrincipal = ResourceGlobal.TituloPaginaCadastro,
                NomeView = @ViewsProject.ViewCadastro,
                NomeControle = ControllerProject.Usuario
            });


            ListaMenus.Add(new MenuPadrao
  {
      IdNomeMenu = @ViewsProject.ViewLoginUsuario,
      TituloPaginaPrincipal = ResourceGlobal.TituloPaginaLogin,
      NomeView = @ViewsProject.ViewLoginUsuario,
      NomeControle = ControllerProject.Usuario
  });


            return ListaMenus;
        }
    }
}
