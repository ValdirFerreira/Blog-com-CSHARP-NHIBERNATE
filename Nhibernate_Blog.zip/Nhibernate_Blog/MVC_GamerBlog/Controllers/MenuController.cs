﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_GamerBlog.Helpers;
using MVC_GamerBlog.Models;
using Entidades.MenuBase;
using MVC_GamerBlog.App_LocalResources;
using Modelo;
using Entidades.Grupos;
using Entidades.Usuarios;

namespace MVC_GamerBlog.Controllers
{
    public class MenuController : BaseController
    {

        Sessoes sessao = new Sessoes();

        public ActionResult Index()
        {

            Session[Sessoes._SetMenu] = ViewsProject.ViewPrincipal;

            ViewBag.Controller = ControllerProject.Usuario;
            ViewBag.Action = ViewsProject.ViewPrincipal;
            return View(ViewsProject.ViewPrincipal);
        }

        public ActionResult Principal()
        {
            Session[Sessoes._SetMenu] = ViewsProject.ViewPrincipal;

            ViewBag.Controller = ControllerProject.Usuario;
            ViewBag.Action = ViewsProject.ViewPrincipal;
            return View(ViewsProject.ViewPrincipal);
        }

        public ActionResult Cadastro()
        {
            Session[Sessoes._SetMenu] = ViewsProject.ViewCadastro;

            ViewBag.Controller = ControllerProject.Usuario;
            ViewBag.Action = ViewsProject.ViewCadastro;
            return View(ViewsProject.ViewCadastro);
        }

        public ActionResult LoginUsuario()
        {
            sessao.RemoverSessaoUsuario();

            Session[Sessoes._SetMenu] = ViewsProject.ViewLoginUsuario;

            ViewBag.Controller = ControllerProject.LoginController;
            ViewBag.Action = ViewsProject.ViewLoginUsuario;
            return View(ViewsProject.ViewLoginUsuario);
        }

        public ActionResult Grupo()
        {

            if (!sessao.VerificaSessaoUsuario())
                return View(ViewsProject.ViewPrincipal);
            else
            {
                Session[Sessoes._SetMenu] = ViewsProject.ViewGrupo;
                ViewBag.Controller = ControllerProject.Usuario;
                ViewBag.Action = ViewsProject.ViewGrupo;


                return View(ViewsProject.ViewGrupo);
            }
        }

        public ActionResult ListaGrupo()
        {
            AplicacaoGrupo Aplicacao = new AplicacaoGrupo();

            if (!sessao.VerificaSessaoUsuario())
                return View(ViewsProject.ViewPrincipal);
            else
            {
                List<CadastroGrupoViewModel> novo = new List<CadastroGrupoViewModel>();

                foreach (var item in Aplicacao.ListaGrupos())
                {
                    novo.Add(new CadastroGrupoViewModel
                   {
                       PrimaryKey = item.Id.ToString(),
                       Nome = item.Nome,
                       NomeClan = item.NomeClan,
                       HoraInicio = item.HoraInicio,
                       DataJogada = item.Data
                   });
                }

                Session[Sessoes._SetMenu] = ViewsProject.ViewListaGrupo;
                ViewBag.Controller = ControllerProject.Usuario;
                ViewBag.Action = ViewsProject.ViewListaGrupo;
                return View(ViewsProject.ViewListaGrupo, novo);
            }
        }
    }
}
