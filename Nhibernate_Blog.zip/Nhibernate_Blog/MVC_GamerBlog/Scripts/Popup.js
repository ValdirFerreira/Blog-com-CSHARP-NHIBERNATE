﻿jQuery.fn.center = function () {
    this.css("top", Math.max(0, (($(window).height() - this.outerHeight()) / 2) + $(window).scrollTop()) + "px");
    this.css("left", Math.max(0, (($(window).width() - this.outerWidth()) / 2) + $(window).scrollLeft()) + "px");
    return this;
};

$(window).resize(function () {
    $(".popup").center();
});

function ExibirPopup(idElemento) {
    var zIndexUltimoPopupExibido = $(".ultimoPopupExibido").css("z-index");
    $(".ultimoPopupExibido").removeClass("ultimoPopupExibido");
    $(".ultimoPopupFundoExibido").removeClass("ultimoPopupFundoExibido");

    var elemento = $("#" + idElemento);
    elemento.addClass("ultimoPopupExibido");

    var idElementoFundo = idElemento + "Fundo";
    elemento.parent().append("<div id='" + idElementoFundo + "' class='popupFundo'></div>");
    var elementoFundo = $("#" + idElementoFundo);
    elementoFundo.addClass("ultimoPopupFundoExibido");

    if (zIndexUltimoPopupExibido != null) {
        elementoFundo.css("z-index", parseInt(zIndexUltimoPopupExibido) + 1);
        elemento.css("z-index", parseInt(zIndexUltimoPopupExibido) + 2);
    }

    elementoFundo.show();
    elemento.center();
    elemento.show();
}

function EsconderPopup(idElemento) {
    var elemento = $("#" + idElemento);
    var idElementoFundo = idElemento + "Fundo";
    var elementoFundo = $("#" + idElementoFundo);
    elementoFundo.hide();
    elemento.hide();
}