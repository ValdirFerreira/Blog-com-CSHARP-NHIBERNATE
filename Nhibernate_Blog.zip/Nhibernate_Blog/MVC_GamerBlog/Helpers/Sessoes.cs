﻿using Entidades.Usuarios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace MVC_GamerBlog.Helpers
{
    public class Sessoes
    {

        private const string _SessaoUsuario = "Usuario";

        public static string _SetMenu = "SetMenu";

        public static string _SessaoidGrupo = "SessaoidGrupo";

        public void IncluirSessaoIdGrupo(string SessaoidGrupo)
        {
            HttpContext.Current.Session[_SessaoidGrupo] = SessaoidGrupo;
        }


        public string ObterSessaoIdGrupo()
        {
            try
            {
                return HttpContext.Current.Session[_SessaoidGrupo].ToString();
            }
            catch (Exception)
            {

                return string.Empty;
            }

        }



        public void IncluirSessaoUsuario(Usuario SessaoUsuario)
        {
            HttpContext.Current.Session[_SessaoUsuario] = SessaoUsuario;
        }

        public Usuario ObterSessaoUsuario()
        {
            try
            {
                return (Usuario)HttpContext.Current.Session[_SessaoUsuario];
            }
            catch (Exception)
            {

                return new Usuario { Id = 0 };
            }

        }

        public void RemoverSessaoUsuario()
        {
            HttpContext.Current.Session[_SessaoUsuario] = null;
        }


        public bool VerificaSessaoUsuario()
        {
            if (HttpContext.Current.Session[_SessaoUsuario] == null)
                return false;
            else
                return true;
        }


    }


}
