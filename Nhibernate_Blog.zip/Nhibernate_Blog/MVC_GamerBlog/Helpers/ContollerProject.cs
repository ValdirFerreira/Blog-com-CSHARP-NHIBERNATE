﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_GamerBlog.Helpers
{
    public static class ControllerProject
    {
        public static string Usuario = "Usuario";
        public static string LoginController = "Login";

    }
}