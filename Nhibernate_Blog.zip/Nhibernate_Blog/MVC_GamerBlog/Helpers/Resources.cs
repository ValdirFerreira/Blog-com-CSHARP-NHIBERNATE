﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_GamerBlog.Helpers
{
    public class Resources
    {
        public const string CampoData = "CampoData";
        public const string CampoEmail = "CampoEmail";
        public const string CampoEntreCaracteres = "CampoEntreCaracteres";
        public const string CampoIgual = "CampoIgual";
        public const string CampoMaximoCaracteres = "CampoMaximoCaracteres";
        public const string CampoNumero = "CampoNumero";
        public const string CampoObrigatorio = "CampoObrigatorio";
        public const string CampoRegexEmail = "CampoRegexEmail";
        public const string CampoRegexHtml = "CampoRegexHtml";
        public const string CampoRegexLogin = "CampoRegexLogin";
        public const string CampoRegexSenha = "CampoRegexSenha";
        public const string CampoRegexUrl = "CampoRegexUrl";
        public const string CampoUnico = "CampoUnico";
    }
}