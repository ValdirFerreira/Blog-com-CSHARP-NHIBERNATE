﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_GamerBlog.Helpers
{
    public static class ViewsProject
    {
        public const string ViewCabecalho = "cabecalho";
        public const string ViewAlerts = "_Alerts";
        public const string ViewRodape = "Rodape";
        public const string ViewPrincipal = "Principal";
        public const string ViewCadastro = "Cadastro";
        public const string ViewLoginUsuario = "LoginUsuario";
        public const string ViewGrupo = "Grupo";
        public const string ViewListaGrupo = "ListaGrupo";

        public const string ViewDetalhesGrupo = "DetalhesGrupo";

        public const string ViewListaUsuariosGrupo = "ListaUsuariosGrupo";

        

    }
}