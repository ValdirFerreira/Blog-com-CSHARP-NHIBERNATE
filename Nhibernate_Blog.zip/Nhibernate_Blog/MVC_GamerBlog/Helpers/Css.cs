﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVC_GamerBlog.Helpers
{
    public static class Css
    {

        //CONSTANTES CSS MASTER PAGE
        public const string Container = "container";
        public const string BodyContainerContent = "container body-content";

        //CONSTANTES CSS CONTROLLES
        public const string LabelOnly = "sr-only";
        public const string ControlLabel = "control-label";
        public const string FormControl = "form-control";

        // CONSTANTES CABEÇALHO 
        public const string NavbarDefault = "navbar-default";
        public const string ContainerFuid = "container-fluid";
        public const string NavBarHeader = " navbar-header";
        public const string NavBaToggleCollapsed = "navbar-toggle collapsed";
        public const string IcoBar = "icon-bar";
        public const string NavBarBrand = "navbar-brand";
        public const string NavBarCollapsedCollapsed = "navbar-collapse collapse";
        public const string NavBarNav = "nav navbar-nav";
        public const string Active = "active";

        //FORMATOS DE NOME E TAMANHO TABELA

        public const string Formatos = "formatos";
        public const string AlinhadoEsquerda = "alinhadoEsquerda";
        public const string AlinhadoDireita = "alinhadoDireita";
        public const string AlinhadoCentro = "alinhadoCentro";
        public const string AlinhadoEsquerdaTitulo = "alinhadoEsquerdaTitulo";
        public const string AlinhadoDireitaTitulo = "alinhadoDireitaTitulo";
        public const string AlinhadoCentroTitulo = "alinhadoCentroTitulo";
        public const string Grid = "grid";
    }
}