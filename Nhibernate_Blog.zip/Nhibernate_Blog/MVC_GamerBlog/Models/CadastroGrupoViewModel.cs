﻿using MVC_GamerBlog.App_LocalResources;
using MVC_GamerBlog.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;

namespace MVC_GamerBlog.Models
{
    public partial class CadastroGrupoViewModel
    {
        public string PrimaryKey { get; set; }

        [Display(ResourceType = typeof(ResourceGlobal), Name = "NomeGrupo")]
        [Required(ErrorMessageResourceType = typeof(ResourceGlobal), ErrorMessageResourceName = Resources.CampoObrigatorio)]
        [StringLength(50, ErrorMessageResourceType = typeof(ResourceGlobal), ErrorMessageResourceName = Resources.CampoMaximoCaracteres)]
        public string Nome { get; set; }

        [Display(ResourceType = typeof(ResourceGlobal), Name = "NomeClan")]
        [Required(ErrorMessageResourceType = typeof(ResourceGlobal), ErrorMessageResourceName = Resources.CampoObrigatorio)]
        [StringLength(50, ErrorMessageResourceType = typeof(ResourceGlobal), ErrorMessageResourceName = Resources.CampoMaximoCaracteres)]
        public string NomeClan { get; set; }

        [Display(ResourceType = typeof(ResourceGlobal), Name = "DataJogada")]
        [Required(ErrorMessageResourceType = typeof(ResourceGlobal), ErrorMessageResourceName = Resources.CampoObrigatorio)]
        //  [StringLength(50, ErrorMessageResourceType = typeof(ResourceGlobal), ErrorMessageResourceName = Resources.CampoMaximoCaracteres)]
        public DateTime DataJogada { get; set; }

        [Display(ResourceType = typeof(ResourceGlobal), Name = "HoraInicio")]
        [Required(ErrorMessageResourceType = typeof(ResourceGlobal), ErrorMessageResourceName = Resources.CampoObrigatorio)]
        //   [StringLength(5, ErrorMessageResourceType = typeof(ResourceGlobal), ErrorMessageResourceName = Resources.CampoMaximoCaracteres)]
        public string HoraInicio { get; set; }

        [Display(ResourceType = typeof(ResourceGlobal), Name = "UsuarioCriador")]
        public string UsuarioCriador { get; set; }
    }
}
