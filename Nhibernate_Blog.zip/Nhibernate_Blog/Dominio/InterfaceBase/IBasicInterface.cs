﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dominio.InterfaceBase
{
    public interface IBasicInterface<T>
    {
        void Insert(T entidade);
        void Update(T entidade);
        void Delete(T entidade);
        T RetornarPorId(int Id);
        IList<T> Consultar();

    }
}
