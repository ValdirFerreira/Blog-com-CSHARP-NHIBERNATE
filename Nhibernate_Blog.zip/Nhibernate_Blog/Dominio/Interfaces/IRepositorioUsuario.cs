﻿using Dominio.InterfaceBase;
using Entidades.Usuarios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dominio.Interfaces
{
    public interface IRepositorioUsuario : IBasicInterface<Usuario>
    {
         Usuario RetornarPorEmail(string Email);

    }
}
