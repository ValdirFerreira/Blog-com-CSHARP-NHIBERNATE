﻿using Dominio.InterfaceBase;
using Entidades.Grupos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dominio.Interfaces
{
    public interface IRepositorioUsuariosGrupo : IBasicInterface<UsuarioGrupo>
    {
    }
}
