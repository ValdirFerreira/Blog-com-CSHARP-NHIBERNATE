﻿using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.Usuarios.Mapeamento
{
    public class MapeamentoUsuario : ClassMap<Usuario>
    {
        public MapeamentoUsuario()
        {
            Table("Usuarios");
            Id(U => U.Id).UniqueKey("Id");
            Map(U => U.Login);
            Map(U => U.Nome);
            Map(U => U.Senha);
            Map(U => U.Ativo);
            //References<TipoUsuario>(x => x.Tipo).Column("Id").ForeignKey().Insert().Update();
            References<TipoUsuario>(x => x.Tipo).Column("IdTipo").ForeignKey();
        }
    }
}
