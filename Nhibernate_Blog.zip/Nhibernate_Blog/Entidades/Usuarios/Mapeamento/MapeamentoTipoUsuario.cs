﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FluentNHibernate.Mapping;

namespace Entidades.Usuarios.Mapeamento
{
    public class MapeamentoTipoUsuario : ClassMap<TipoUsuario>
    {

        public MapeamentoTipoUsuario()
        {
            Table("TipoUsuario");
            Id(U => U.IdTipo).UniqueKey("Id"); ;
            Map(U => U.NomeTipo);
        }
    }
}
