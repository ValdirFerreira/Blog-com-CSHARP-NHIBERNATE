﻿using Entidades.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.Usuarios
{
    public class TipoUsuario 
    {
        public virtual int IdTipo { get; set; }
        public virtual string NomeTipo { get; set; }
    }
}
