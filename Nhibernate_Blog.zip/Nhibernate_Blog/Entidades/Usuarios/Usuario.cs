﻿using Entidades.Base;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.Usuarios
{
    public class Usuario : EntidadeBase
    {
        public virtual string Login { get; set; }
        public virtual string Senha { get; set; }
        public virtual bool Ativo { get; set; }
        public virtual TipoUsuario Tipo { get; set; }
    }
}
