﻿using Entidades.Base;
using Entidades.Usuarios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.Grupos
{
    public class Grupo : EntidadeBase
    {
        public virtual string NomeClan { get; set; }
        public virtual string HoraInicio { get; set; }
        public virtual DateTime Data { get; set; }
        public virtual int IdUsuarioCriador { get; set; }
    }
}
