﻿using Entidades.Usuarios;
using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.Grupos.Mapeamento
{
    public class MapeamentoGrupo : ClassMap<Grupo>
    {
        public MapeamentoGrupo()
        {
            Table("Grupos");
            Id(U => U.Id).UniqueKey("Id");
            Map(U => U.Nome);
            Map(U => U.NomeClan);
            Map(U => U.HoraInicio);
            Map(U => U.Data);
            Map(U => U.IdUsuarioCriador);

          //  References<Usuario>(x => x.Id).Column("IdUsuarioCriador").ForeignKey();
        }
    }
}
