﻿using Entidades.Usuarios;
using FluentNHibernate.Mapping;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.Grupos.Mapeamento
{
    public class MapeamentoUsuarioGrupo : ClassMap<UsuarioGrupo>
    {
        public MapeamentoUsuarioGrupo()
        {
            Table("UsuarioGrupo");
            Id(U => U.id).UniqueKey("Id");
            Map(U => U.idGrupo);
            Map(U => U.idUsuario);
            //References<Grupo>(x => x.id).Column("IdGrupo").ForeignKey();
            //References<Usuario>(x => x.id).Column("IdUsuario").ForeignKey();
        }

    }
}
