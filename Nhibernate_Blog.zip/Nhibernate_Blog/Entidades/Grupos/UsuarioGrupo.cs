﻿using Entidades.Usuarios;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.Grupos
{
    public class UsuarioGrupo
    {
        public virtual int id { get; set; }
        public virtual int idUsuario { get; set; }
        public virtual int idGrupo { get; set; }
    }
}
