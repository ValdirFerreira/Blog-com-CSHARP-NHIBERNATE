﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Entidades.MenuBase
{
    public class MenuPadrao
    {
        public virtual string IdNomeMenu { get; set; }
        public virtual string TituloPaginaPrincipal { get; set; }
        public virtual string NomeView { get; set; }
        public virtual string NomeControle { get; set; }

    }
}
